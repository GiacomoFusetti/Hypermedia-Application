# Hypermedia-Application
# General information about the team and the web application
-  **Heroku URL:** https://bookstore-hype.herokuapp.com/
- **Team administrator:** Giovanni Maria, Gianola, 10451768, GiovanniGianola
- **Team member n.2 :** Giacomo, Fusetti, 10434444, GiacomoFusetti

# Description of the Project
The web site is for an on-line BOOK STORE and its multimedia contents are about paper-based and digital Books and their Authors. The web site also includes Events where Books are presented for promotional purposes by their Author.
Each book is described by a picture, a “fact sheet”, an abstract and a set of reviews, and optionally an interview with the author. Each Author is described by a picture and a short bio. Each Book is related to its Author and to a set of Books that are “similar to” it. Each Author is related to his/her books.
For the purpose of your project, the web site offers 2 main functionalities: User Registration and Book Reservation
